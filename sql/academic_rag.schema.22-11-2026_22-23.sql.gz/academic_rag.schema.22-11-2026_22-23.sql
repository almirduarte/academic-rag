--
-- PostgreSQL database dump
--

\restrict ZhPqMJ8WgUtuy3adVZ2v66F6SrLeNchn2tZBqrDFswEcK358yuaghMtYVwBz4x9

-- Dumped from database version 15.20
-- Dumped by pg_dump version 15.20

-- Started on 2026-11-22 22:23:25 -03

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 7 (class 2615 OID 3256571)
-- Name: URX_PUBLIC; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "URX_PUBLIC";


ALTER SCHEMA "URX_PUBLIC" OWNER TO postgres;

--
-- TOC entry 2 (class 3079 OID 2294842)
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- TOC entry 4606 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- TOC entry 354 (class 1255 OID 3260210)
-- Name: _urx_transactions_dt(); Type: FUNCTION; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

CREATE FUNCTION "URX_PUBLIC"._urx_transactions_dt() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
		NEW.tra_dt := NOW();
		RETURN NEW;
	END;
$$;


ALTER FUNCTION "URX_PUBLIC"._urx_transactions_dt() OWNER TO "URX_PUBLIC";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 224 (class 1259 OID 3260485)
-- Name: auth_sessions; Type: TABLE; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

CREATE TABLE "URX_PUBLIC".auth_sessions (
    token_hash character varying(64) NOT NULL,
    user_id smallint NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


ALTER TABLE "URX_PUBLIC".auth_sessions OWNER TO "URX_PUBLIC";

--
-- TOC entry 217 (class 1259 OID 3256573)
-- Name: document_chunks; Type: TABLE; Schema: URX_PUBLIC; Owner: postgres
--

CREATE TABLE "URX_PUBLIC".document_chunks (
    id bigint NOT NULL,
    source_file text NOT NULL,
    chunk_index integer NOT NULL,
    content text NOT NULL,
    embedding public.vector(768) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE "URX_PUBLIC".document_chunks OWNER TO postgres;

--
-- TOC entry 216 (class 1259 OID 3256572)
-- Name: document_chunks_id_seq; Type: SEQUENCE; Schema: URX_PUBLIC; Owner: postgres
--

CREATE SEQUENCE "URX_PUBLIC".document_chunks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "URX_PUBLIC".document_chunks_id_seq OWNER TO postgres;

--
-- TOC entry 4607 (class 0 OID 0)
-- Dependencies: 216
-- Name: document_chunks_id_seq; Type: SEQUENCE OWNED BY; Schema: URX_PUBLIC; Owner: postgres
--

ALTER SEQUENCE "URX_PUBLIC".document_chunks_id_seq OWNED BY "URX_PUBLIC".document_chunks.id;


--
-- TOC entry 228 (class 1259 OID 3287386)
-- Name: document_jobs; Type: TABLE; Schema: URX_PUBLIC; Owner: postgres
--

CREATE TABLE "URX_PUBLIC".document_jobs (
    job_id uuid NOT NULL,
    operation text NOT NULL,
    state text NOT NULL,
    document_id bigint,
    requested_by smallint NOT NULL,
    source_file text NOT NULL,
    title text NOT NULL,
    expected_revision bigint,
    expected_fingerprint text,
    expected_source text,
    upload_sha256 text,
    prepared_sha256 text,
    message text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT document_jobs_operation_check CHECK ((operation = ANY (ARRAY['include'::text, 'replace'::text, 'delete'::text]))),
    CONSTRAINT document_jobs_state_check CHECK ((state = ANY (ARRAY['queued'::text, 'processing'::text, 'review'::text, 'approved'::text, 'publishing'::text, 'done'::text, 'failed'::text, 'cancelled'::text])))
);


ALTER TABLE "URX_PUBLIC".document_jobs OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 3259477)
-- Name: document_summaries; Type: TABLE; Schema: URX_PUBLIC; Owner: postgres
--

CREATE TABLE "URX_PUBLIC".document_summaries (
    id bigint NOT NULL,
    source_file text NOT NULL,
    summary_type text NOT NULL,
    book_number smallint,
    content text NOT NULL,
    embedding public.vector(768) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT document_summaries_check CHECK ((((summary_type = 'work'::text) AND (book_number IS NULL)) OR ((summary_type = 'book'::text) AND ((book_number >= 1) AND (book_number <= 10))))),
    CONSTRAINT document_summaries_summary_type_check CHECK ((summary_type = ANY (ARRAY['work'::text, 'book'::text])))
);


ALTER TABLE "URX_PUBLIC".document_summaries OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 3259476)
-- Name: document_summaries_id_seq; Type: SEQUENCE; Schema: URX_PUBLIC; Owner: postgres
--

CREATE SEQUENCE "URX_PUBLIC".document_summaries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "URX_PUBLIC".document_summaries_id_seq OWNER TO postgres;

--
-- TOC entry 4608 (class 0 OID 0)
-- Dependencies: 218
-- Name: document_summaries_id_seq; Type: SEQUENCE OWNED BY; Schema: URX_PUBLIC; Owner: postgres
--

ALTER SEQUENCE "URX_PUBLIC".document_summaries_id_seq OWNED BY "URX_PUBLIC".document_summaries.id;


--
-- TOC entry 227 (class 1259 OID 3287364)
-- Name: documents; Type: TABLE; Schema: URX_PUBLIC; Owner: postgres
--

CREATE TABLE "URX_PUBLIC".documents (
    doc_id bigint NOT NULL,
    source_file text NOT NULL,
    title text NOT NULL,
    storage_name text NOT NULL,
    sha256 character(64) NOT NULL,
    size_bytes bigint NOT NULL,
    registered_at timestamp with time zone DEFAULT now() NOT NULL,
    revision bigint DEFAULT 1 NOT NULL,
    CONSTRAINT documents_sha256_check CHECK ((sha256 ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT documents_size_bytes_check CHECK (((size_bytes > 0) AND (size_bytes <= 52428800))),
    CONSTRAINT documents_source_file_check CHECK (((source_file <> ''::text) AND (source_file !~ '[/\\]'::text))),
    CONSTRAINT documents_storage_name_check CHECK ((storage_name ~ '^([^/\\]+|_managed/[0-9a-f]{32}[.]pdf)$'::text)),
    CONSTRAINT documents_title_check CHECK (((length(btrim(title)) >= 1) AND (length(btrim(title)) <= 300)))
);


ALTER TABLE "URX_PUBLIC".documents OWNER TO postgres;

--
-- TOC entry 4609 (class 0 OID 0)
-- Dependencies: 227
-- Name: TABLE documents; Type: COMMENT; Schema: URX_PUBLIC; Owner: postgres
--

COMMENT ON TABLE "URX_PUBLIC".documents IS 'Catálogo de documentos indexados. source_file liga o catálogo à carga existente; doc_id é a identidade estável.';


--
-- TOC entry 226 (class 1259 OID 3287363)
-- Name: documents_doc_id_seq; Type: SEQUENCE; Schema: URX_PUBLIC; Owner: postgres
--

CREATE SEQUENCE "URX_PUBLIC".documents_doc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "URX_PUBLIC".documents_doc_id_seq OWNER TO postgres;

--
-- TOC entry 4610 (class 0 OID 0)
-- Dependencies: 226
-- Name: documents_doc_id_seq; Type: SEQUENCE OWNED BY; Schema: URX_PUBLIC; Owner: postgres
--

ALTER SEQUENCE "URX_PUBLIC".documents_doc_id_seq OWNED BY "URX_PUBLIC".documents.doc_id;


--
-- TOC entry 225 (class 1259 OID 3261012)
-- Name: email_confirmations; Type: TABLE; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

CREATE TABLE "URX_PUBLIC".email_confirmations (
    user_id smallint NOT NULL,
    token_hash character varying(64) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    issued_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT email_confirmations_token_hash_check CHECK (((token_hash)::text ~ '^[0-9a-f]{64}$'::text))
);


ALTER TABLE "URX_PUBLIC".email_confirmations OWNER TO "URX_PUBLIC";

--
-- TOC entry 220 (class 1259 OID 3260203)
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

CREATE SEQUENCE "URX_PUBLIC".transactions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "URX_PUBLIC".transactions_id_seq OWNER TO "URX_PUBLIC";

--
-- TOC entry 221 (class 1259 OID 3260204)
-- Name: transactions; Type: TABLE; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

CREATE TABLE "URX_PUBLIC".transactions (
    tra_dt timestamp with time zone NOT NULL,
    tra_id integer DEFAULT nextval('"URX_PUBLIC".transactions_id_seq'::regclass) NOT NULL,
    tra_user bigint,
    tra_ip_address character varying(15),
    tra_request character varying(2000)
);


ALTER TABLE "URX_PUBLIC".transactions OWNER TO "URX_PUBLIC";

--
-- TOC entry 4611 (class 0 OID 0)
-- Dependencies: 221
-- Name: TABLE transactions; Type: COMMENT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

COMMENT ON TABLE "URX_PUBLIC".transactions IS 'Sistema - Transação do Usuário';


--
-- TOC entry 4612 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN transactions.tra_dt; Type: COMMENT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

COMMENT ON COLUMN "URX_PUBLIC".transactions.tra_dt IS 'Data-Hora';


--
-- TOC entry 4613 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN transactions.tra_id; Type: COMMENT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

COMMENT ON COLUMN "URX_PUBLIC".transactions.tra_id IS 'Identificador';


--
-- TOC entry 4614 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN transactions.tra_user; Type: COMMENT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

COMMENT ON COLUMN "URX_PUBLIC".transactions.tra_user IS 'Identificador interno em users.id';


--
-- TOC entry 4615 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN transactions.tra_ip_address; Type: COMMENT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

COMMENT ON COLUMN "URX_PUBLIC".transactions.tra_ip_address IS 'Endereço IP';


--
-- TOC entry 4616 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN transactions.tra_request; Type: COMMENT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

COMMENT ON COLUMN "URX_PUBLIC".transactions.tra_request IS 'Pergunta';


--
-- TOC entry 222 (class 1259 OID 3260458)
-- Name: users_id_seq; Type: SEQUENCE; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

CREATE SEQUENCE "URX_PUBLIC".users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 32767
    CACHE 1;


ALTER TABLE "URX_PUBLIC".users_id_seq OWNER TO "URX_PUBLIC";

--
-- TOC entry 223 (class 1259 OID 3260459)
-- Name: users; Type: TABLE; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

CREATE TABLE "URX_PUBLIC".users (
    use_id smallint DEFAULT nextval('"URX_PUBLIC".users_id_seq'::regclass) NOT NULL,
    use_setor smallint NOT NULL,
    use_password character varying(255) NOT NULL,
    use_cpf character varying(11) NOT NULL,
    use_email character varying(50) NOT NULL,
    use_nome_completo character varying(200) NOT NULL,
    use_ip_address character varying(20) NOT NULL,
    use_email_confirmed boolean DEFAULT false NOT NULL,
    use_email_confirmed_at timestamp with time zone,
    use_admin boolean DEFAULT false NOT NULL,
    CONSTRAINT ck_users_cpf CHECK (((use_cpf IS NULL) OR ((use_cpf)::text ~ '^[0-9]{11}$'::text))),
    CONSTRAINT ck_users_email CHECK ((((use_email)::text = btrim((use_email)::text)) AND ((use_email)::text <> ''::text))),
    CONSTRAINT ck_users_setor CHECK (((use_setor >= 1) AND (use_setor <= 5)))
);


ALTER TABLE "URX_PUBLIC".users OWNER TO "URX_PUBLIC";

--
-- TOC entry 4617 (class 0 OID 0)
-- Dependencies: 223
-- Name: TABLE users; Type: COMMENT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

COMMENT ON TABLE "URX_PUBLIC".users IS 'Sistema - Usuário';


--
-- TOC entry 4618 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN users.use_id; Type: COMMENT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

COMMENT ON COLUMN "URX_PUBLIC".users.use_id IS 'Identificador';


--
-- TOC entry 4619 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN users.use_setor; Type: COMMENT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

COMMENT ON COLUMN "URX_PUBLIC".users.use_setor IS 'Setor
    Valores válidos:
    1. Comando
    2. SE
    3. SA
    4. ComCA - Oficiais
    5. ComCA - Aspirantes
    Obs.: o setor será tratado como Dados de código.';


--
-- TOC entry 4620 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN users.use_password; Type: COMMENT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

COMMENT ON COLUMN "URX_PUBLIC".users.use_password IS 'Senha';


--
-- TOC entry 4621 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN users.use_cpf; Type: COMMENT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

COMMENT ON COLUMN "URX_PUBLIC".users.use_cpf IS 'CPF';


--
-- TOC entry 4622 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN users.use_email; Type: COMMENT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

COMMENT ON COLUMN "URX_PUBLIC".users.use_email IS 'E-mail';


--
-- TOC entry 4623 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN users.use_nome_completo; Type: COMMENT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

COMMENT ON COLUMN "URX_PUBLIC".users.use_nome_completo IS 'Nome completo';


--
-- TOC entry 4624 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN users.use_ip_address; Type: COMMENT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

COMMENT ON COLUMN "URX_PUBLIC".users.use_ip_address IS 'Endereço IP';


--
-- TOC entry 4625 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN users.use_email_confirmed; Type: COMMENT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

COMMENT ON COLUMN "URX_PUBLIC".users.use_email_confirmed IS 'E-mail confirmado; contas anteriores à migração foram liberadas por compatibilidade.';


--
-- TOC entry 4626 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN users.use_email_confirmed_at; Type: COMMENT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

COMMENT ON COLUMN "URX_PUBLIC".users.use_email_confirmed_at IS 'Data da confirmação por link; NULL nas contas legadas liberadas pela migração.';


--
-- TOC entry 4627 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN users.use_admin; Type: COMMENT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

COMMENT ON COLUMN "URX_PUBLIC".users.use_admin IS 'Autoriza a administração dos documentos do Farol Acadêmico.';


--
-- TOC entry 4392 (class 2604 OID 3256576)
-- Name: document_chunks id; Type: DEFAULT; Schema: URX_PUBLIC; Owner: postgres
--

ALTER TABLE ONLY "URX_PUBLIC".document_chunks ALTER COLUMN id SET DEFAULT nextval('"URX_PUBLIC".document_chunks_id_seq'::regclass);


--
-- TOC entry 4394 (class 2604 OID 3259480)
-- Name: document_summaries id; Type: DEFAULT; Schema: URX_PUBLIC; Owner: postgres
--

ALTER TABLE ONLY "URX_PUBLIC".document_summaries ALTER COLUMN id SET DEFAULT nextval('"URX_PUBLIC".document_summaries_id_seq'::regclass);


--
-- TOC entry 4401 (class 2604 OID 3287367)
-- Name: documents doc_id; Type: DEFAULT; Schema: URX_PUBLIC; Owner: postgres
--

ALTER TABLE ONLY "URX_PUBLIC".documents ALTER COLUMN doc_id SET DEFAULT nextval('"URX_PUBLIC".documents_doc_id_seq'::regclass);


--
-- TOC entry 4438 (class 2606 OID 3260489)
-- Name: auth_sessions auth_sessions_pkey; Type: CONSTRAINT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

ALTER TABLE ONLY "URX_PUBLIC".auth_sessions
    ADD CONSTRAINT auth_sessions_pkey PRIMARY KEY (token_hash);


--
-- TOC entry 4421 (class 2606 OID 3256581)
-- Name: document_chunks document_chunks_pkey; Type: CONSTRAINT; Schema: URX_PUBLIC; Owner: postgres
--

ALTER TABLE ONLY "URX_PUBLIC".document_chunks
    ADD CONSTRAINT document_chunks_pkey PRIMARY KEY (id);


--
-- TOC entry 4451 (class 2606 OID 3287397)
-- Name: document_jobs document_jobs_pkey; Type: CONSTRAINT; Schema: URX_PUBLIC; Owner: postgres
--

ALTER TABLE ONLY "URX_PUBLIC".document_jobs
    ADD CONSTRAINT document_jobs_pkey PRIMARY KEY (job_id);


--
-- TOC entry 4425 (class 2606 OID 3259487)
-- Name: document_summaries document_summaries_pkey; Type: CONSTRAINT; Schema: URX_PUBLIC; Owner: postgres
--

ALTER TABLE ONLY "URX_PUBLIC".document_summaries
    ADD CONSTRAINT document_summaries_pkey PRIMARY KEY (id);


--
-- TOC entry 4445 (class 2606 OID 3287377)
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: URX_PUBLIC; Owner: postgres
--

ALTER TABLE ONLY "URX_PUBLIC".documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (doc_id);


--
-- TOC entry 4447 (class 2606 OID 3287379)
-- Name: documents documents_source_file_key; Type: CONSTRAINT; Schema: URX_PUBLIC; Owner: postgres
--

ALTER TABLE ONLY "URX_PUBLIC".documents
    ADD CONSTRAINT documents_source_file_key UNIQUE (source_file);


--
-- TOC entry 4449 (class 2606 OID 3287381)
-- Name: documents documents_storage_name_key; Type: CONSTRAINT; Schema: URX_PUBLIC; Owner: postgres
--

ALTER TABLE ONLY "URX_PUBLIC".documents
    ADD CONSTRAINT documents_storage_name_key UNIQUE (storage_name);


--
-- TOC entry 4441 (class 2606 OID 3261018)
-- Name: email_confirmations email_confirmations_pkey; Type: CONSTRAINT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

ALTER TABLE ONLY "URX_PUBLIC".email_confirmations
    ADD CONSTRAINT email_confirmations_pkey PRIMARY KEY (user_id);


--
-- TOC entry 4443 (class 2606 OID 3261020)
-- Name: email_confirmations email_confirmations_token_hash_key; Type: CONSTRAINT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

ALTER TABLE ONLY "URX_PUBLIC".email_confirmations
    ADD CONSTRAINT email_confirmations_token_hash_key UNIQUE (token_hash);


--
-- TOC entry 4429 (class 2606 OID 3260209)
-- Name: transactions pk_transactions; Type: CONSTRAINT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

ALTER TABLE ONLY "URX_PUBLIC".transactions
    ADD CONSTRAINT pk_transactions PRIMARY KEY (tra_id);


--
-- TOC entry 4431 (class 2606 OID 3260469)
-- Name: users pk_users; Type: CONSTRAINT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

ALTER TABLE ONLY "URX_PUBLIC".users
    ADD CONSTRAINT pk_users PRIMARY KEY (use_id);


--
-- TOC entry 4433 (class 2606 OID 3260471)
-- Name: users uk_users_cpf; Type: CONSTRAINT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

ALTER TABLE ONLY "URX_PUBLIC".users
    ADD CONSTRAINT uk_users_cpf UNIQUE (use_cpf);


--
-- TOC entry 4435 (class 2606 OID 3260473)
-- Name: users uk_users_email; Type: CONSTRAINT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

ALTER TABLE ONLY "URX_PUBLIC".users
    ADD CONSTRAINT uk_users_email UNIQUE (use_email);


--
-- TOC entry 4422 (class 1259 OID 3256582)
-- Name: idx_document_chunks_embedding; Type: INDEX; Schema: URX_PUBLIC; Owner: postgres
--

CREATE INDEX idx_document_chunks_embedding ON "URX_PUBLIC".document_chunks USING hnsw (embedding public.vector_cosine_ops);


--
-- TOC entry 4423 (class 1259 OID 3256583)
-- Name: idx_document_chunks_source_file; Type: INDEX; Schema: URX_PUBLIC; Owner: postgres
--

CREATE INDEX idx_document_chunks_source_file ON "URX_PUBLIC".document_chunks USING btree (source_file);


--
-- TOC entry 4427 (class 1259 OID 3260239)
-- Name: idx_transactions_user; Type: INDEX; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

CREATE INDEX idx_transactions_user ON "URX_PUBLIC".transactions USING btree (tra_user);


--
-- TOC entry 4439 (class 1259 OID 3260495)
-- Name: ix_auth_sessions_expiry; Type: INDEX; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

CREATE INDEX ix_auth_sessions_expiry ON "URX_PUBLIC".auth_sessions USING btree (expires_at);


--
-- TOC entry 4436 (class 1259 OID 3260484)
-- Name: uk_users_email_lower; Type: INDEX; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

CREATE UNIQUE INDEX uk_users_email_lower ON "URX_PUBLIC".users USING btree (lower((use_email)::text));


--
-- TOC entry 4452 (class 1259 OID 3287404)
-- Name: uq_document_job_source; Type: INDEX; Schema: URX_PUBLIC; Owner: postgres
--

CREATE UNIQUE INDEX uq_document_job_source ON "URX_PUBLIC".document_jobs USING btree (source_file) WHERE (state = ANY (ARRAY['queued'::text, 'processing'::text, 'review'::text, 'approved'::text, 'publishing'::text]));


--
-- TOC entry 4453 (class 1259 OID 3287403)
-- Name: uq_document_job_target; Type: INDEX; Schema: URX_PUBLIC; Owner: postgres
--

CREATE UNIQUE INDEX uq_document_job_target ON "URX_PUBLIC".document_jobs USING btree (document_id) WHERE ((document_id IS NOT NULL) AND (state = ANY (ARRAY['queued'::text, 'processing'::text, 'review'::text, 'approved'::text, 'publishing'::text])));


--
-- TOC entry 4426 (class 1259 OID 3259488)
-- Name: uq_document_summaries_scope; Type: INDEX; Schema: URX_PUBLIC; Owner: postgres
--

CREATE UNIQUE INDEX uq_document_summaries_scope ON "URX_PUBLIC".document_summaries USING btree (source_file, summary_type, COALESCE((book_number)::integer, 0));


--
-- TOC entry 4458 (class 2620 OID 3260211)
-- Name: transactions tg_transactions_dt; Type: TRIGGER; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

CREATE TRIGGER tg_transactions_dt BEFORE INSERT ON "URX_PUBLIC".transactions FOR EACH ROW EXECUTE FUNCTION "URX_PUBLIC"._urx_transactions_dt();


--
-- TOC entry 4455 (class 2606 OID 3260490)
-- Name: auth_sessions auth_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

ALTER TABLE ONLY "URX_PUBLIC".auth_sessions
    ADD CONSTRAINT auth_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES "URX_PUBLIC".users(use_id) ON DELETE CASCADE;


--
-- TOC entry 4457 (class 2606 OID 3287398)
-- Name: document_jobs document_jobs_requested_by_fkey; Type: FK CONSTRAINT; Schema: URX_PUBLIC; Owner: postgres
--

ALTER TABLE ONLY "URX_PUBLIC".document_jobs
    ADD CONSTRAINT document_jobs_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES "URX_PUBLIC".users(use_id);


--
-- TOC entry 4456 (class 2606 OID 3261021)
-- Name: email_confirmations email_confirmations_user_id_fkey; Type: FK CONSTRAINT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

ALTER TABLE ONLY "URX_PUBLIC".email_confirmations
    ADD CONSTRAINT email_confirmations_user_id_fkey FOREIGN KEY (user_id) REFERENCES "URX_PUBLIC".users(use_id) ON DELETE CASCADE;


--
-- TOC entry 4454 (class 2606 OID 3260496)
-- Name: transactions fk_transactions_user; Type: FK CONSTRAINT; Schema: URX_PUBLIC; Owner: URX_PUBLIC
--

ALTER TABLE ONLY "URX_PUBLIC".transactions
    ADD CONSTRAINT fk_transactions_user FOREIGN KEY (tra_user) REFERENCES "URX_PUBLIC".users(use_id) ON DELETE RESTRICT;


-- Completed on 2026-11-22 22:23:26 -03

--
-- PostgreSQL database dump complete
--

\unrestrict ZhPqMJ8WgUtuy3adVZ2v66F6SrLeNchn2tZBqrDFswEcK358yuaghMtYVwBz4x9

